
package javaodevi;


public class JavaOdevi {

    
    public static void main(String[] args) {
        System.out.println("Hello World");
    }
    
}
